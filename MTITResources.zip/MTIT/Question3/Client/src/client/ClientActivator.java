package client;

import java.util.Scanner;

import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import server.ServiceActions;

/**
 * The activator class controls the plug-in life cycle
 */
public class ClientActivator extends AbstractUIPlugin {
	
	ServiceReference serviceRef;

	// The plug-in ID
	public static final String PLUGIN_ID = "Client"; //$NON-NLS-1$

	// The shared instance
	private static ClientActivator plugin;
	
	/**
	 * The constructor
	 */
	public ClientActivator() {
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
		
		System.out.println("client starts!!");
		serviceRef = context.getServiceReference(ServiceActions.class.getName());
		ServiceActions sactions = (ServiceActions)context.getService(serviceRef);
		//System.out.println(sactions.PrintService());
		
		double no1,no2,ans;
		Scanner reader = new Scanner(System.in); 
		System.out.println("Enter a number1: ");
		no1 = reader.nextDouble();
		System.out.println("Enter a number2: ");
		no2 = reader.nextDouble();		
		
	     	if(no2>no1)
	     	{
		     ans = sactions.add(no1,no2);
	     	}
	     	else
	     	{
	    	 	ans = sactions.substract(no1,no2);
	     	}
	     
	      	System.out.println("Answer is: " + ans);
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static ClientActivator getDefault() {
		return plugin;
	}

}
