package server;

public class ServiceActionsImpl implements ServiceActions {

	@Override
	public String PrintService() {
		// TODO Auto-generated method stub
		return "execute print service";
	}

	@Override
	public String Hello() {
		// TODO Auto-generated method stub
		return "Hello!!";
	}

	@Override
	public double add(double a, double b) {
		// TODO Auto-generated method stub
		return a+b;
	}

	@Override
	public double substract(double a, double b) {
		// TODO Auto-generated method stub
		return a-b;
	}

}
