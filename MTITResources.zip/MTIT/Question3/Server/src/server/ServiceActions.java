package server;

public interface ServiceActions {
	public String PrintService();
	public String Hello();
	public double add(double a,double b);
	public double substract(double a,double b);

}
