package server;

import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

/**
 * The activator class controls the plug-in life cycle
 */
public class ServerActivator extends AbstractUIPlugin {
	
	ServiceRegistration serviceReg;

	// The plug-in ID
	public static final String PLUGIN_ID = "Server"; //$NON-NLS-1$

	// The shared instance
	private static ServerActivator plugin;
	
	/**
	 * The constructor
	 */
	public ServerActivator() {
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
		
		ServiceActions sactions = new ServiceActionsImpl();
		serviceReg = context.registerService(ServiceActions.class.getName(),sactions,null);
		System.out.println("service started");
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
		
		serviceReg.unregister();
		System.out.println("service stopped");
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static ServerActivator getDefault() {
		return plugin;
	}

}
