package com.mtit.main;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import com.jayway.jsonpath.JsonPath;

public class jpath {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		 String json;
		try {

		  json = readFile("test.json",StandardCharsets.UTF_8 );
		  List<String> result = JsonPath.read(json, "$.store.book[*].author");
		  //String resultm = JsonPath.read(json, "$.store.book[*].author");
		  System.out.println(result);
		  //System.out.println(result.toString());

		} catch (Exception e) {


		// TODO Auto-generated catch block
		  e.printStackTrace();

		}
		} 

		public static String readFile(String path, Charset encoding) throws IOException {

		  byte[] encoded = Files.readAllBytes(Paths.get(path));
		  return new String(encoded, encoding);

		}
		}