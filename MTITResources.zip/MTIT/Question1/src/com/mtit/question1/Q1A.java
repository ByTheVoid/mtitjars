package com.mtit.question1;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Q1A {

	public static void main(String[] args) {

		try {

			Class<?> clz = Class.forName("com.mtit.question1.User");
			Object obj = clz.newInstance();

			Method m = clz.getDeclaredMethod("toString");

			// Field before modification
			System.out.println("Username/password = " + m.invoke(obj));

			// Re-assign through reflection
			Field fieldU = clz.getDeclaredField("username");
			fieldU.setAccessible(true);
			fieldU.set(obj, "MTIT_Admin");

			Field fieldP = clz.getDeclaredField("password");
			fieldP.setAccessible(true);
			fieldP.set(obj, "adminl23");

			// Field After Modification
			System.out.println("Modified Username/password = " + m.invoke(obj));

		} catch (NoSuchFieldException | SecurityException
				| IllegalArgumentException | IllegalAccessException
				| ClassNotFoundException | InstantiationException
				| NoSuchMethodException | InvocationTargetException e) {
			e.printStackTrace();
		}
	}
}

class User {
	private final String username;
	private final String password;

	public User() {
		this.username = "MTIT";
		this.password = "password";
	}

	@Override
	public String toString() {
		return this.username + "/" + this.password;
	}
}
