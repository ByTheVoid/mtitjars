package com.mtit.question1;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class Q1B {

	public static void main(String[] args) {

		try {		
			
			System.out.println("Display Output : ");
			
			Class<?> clazz = Class.forName("com.mtit.question1.Employee");
			
			Constructor<?>  m1 = clazz.getConstructors()[0];
			
			for (Class<?> e : m1.getParameterTypes()) {
				System.out.println( e.getName());
			}
			
			Constructor<?>  m2 = clazz.getConstructor(clazz.getConstructors()[0].getParameterTypes());
			Object obj=m2.newInstance("Tharindu", "Colombo 10", 40001, 85000.50);
			
			Method method = clazz.getDeclaredMethod("displayEmployeeDetails");
			method.invoke(obj);


		} catch ( Exception e) {
			e.printStackTrace();
		}
	}
}

class Employee {

	private final String name;
	private final String address;
	private final int employeeNo;
	private final double salary;

	public Employee(String name, String address, int employeeNo, double salary) {
		super();
		this.name = name;
		this.address = address;
		this.employeeNo = employeeNo;
		this.salary = salary;
	}

	public void displayEmployeeDetails() {
		System.out.println("Employee Name is:- " + this.name);
		System.out.println("Employee Address is:-" + this.address);
		System.out.println("Employee Employee No is:- " + this.employeeNo);
		System.out.println("Emplyee Salary is:- " + this.salary);
	}
}
