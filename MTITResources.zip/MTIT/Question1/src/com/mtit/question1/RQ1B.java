package com.mtit.question1;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class RQ1B {

	public static void main(String[] args) {

		try {

			Class CalculateClass = Class.forName("com.mtit.question1.Calculate");
			Calculate cal = (Calculate) CalculateClass.newInstance();
			Field[] fields = CalculateClass.getDeclaredFields();

			for (Field field : fields) {
				if (java.lang.reflect.Modifier.isStatic(field.getModifiers())
						&& java.lang.reflect.Modifier.isFinal(field.getModifiers())) {
					field.setAccessible(true);
					System.out.println(field.get(cal));
				}
			}
			Method meth = CalculateClass.getDeclaredMethod("calculate",
					String.class);
			meth.invoke(cal, "+");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class Calculate {
	private static final String PLUS = "+";
	private static final String MINUS = "-";
	private static final double NOl = 123.23;
	private static final double N02 = 234.45;

	public void calculate(String sign) {
		if (PLUS.equals(sign)) {
			System.out.println("Value " + plus(NOl, N02));
		} else if (MINUS.equals(sign)) {
			System.out.println("Value " + minus(NOl, N02));
		} else {

			System.out.println("Please enter correct sign");
		}
	}

	public double plus(double no1, double no2) {
		return (no1 + no2);
	}

	public double minus(double nol, double no2) {
		return (nol - no2);
	}

}
