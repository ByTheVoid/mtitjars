package com.mtit.question1;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class RQ1A {

	public static void main(String[] args) {

		try {

			Class<?> clz = Class.forName("com.mtit.question1.Account");
			Object obj = clz.newInstance();

			Method m = clz.getDeclaredMethod("toString");

			// Field before modification
			System.out.println("Accont Details : " + m.invoke(obj));

			// Re-assign through reflection
			Field fieldU = clz.getDeclaredField("accountID");
			fieldU.setAccessible(true);
			fieldU.set(obj, "xxxx-xxxx-xxxx");
			
			Field fieldP = clz.getDeclaredField("amount");			
			fieldP.setAccessible(true);			
			fieldP.set(obj, 0.0);

			// Field After Modification
			System.out.println("Modified Accont Details : " + m.invoke(obj));

		} catch (NoSuchFieldException | SecurityException
				| IllegalArgumentException | IllegalAccessException
				| ClassNotFoundException | InstantiationException
				| NoSuchMethodException | InvocationTargetException e) {
			e.printStackTrace();
		}
	}
}

class Account {
	private final String accountID;
	private final double amount;

	public Account() {
		this.accountID = "1234-5678-9876";
		this.amount = 1000000.00;
	}

	@Override
	public String toString() {
		return "Account = " + this.accountID + ", Amount = " + this.amount;
	}
}
